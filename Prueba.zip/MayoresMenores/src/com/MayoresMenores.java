package com;
import java.util.Scanner;

public class MayoresMenores {

	public static void main(String[] args) 
	{
		//Inicializar Scanner
		
		Scanner teclado;
		teclado = new Scanner (System.in);
		
		//Declaración e inicialización de variables
		int referencia;
		referencia = 0;
		
		int valor1;
		valor1 = 0;
		
		int valor2;
		valor2 = 0;
		
		int valor3;
		valor3 = 0;
		
		int valor4;
		valor4 = 0;
		
		int valor5;
		valor5 = 0;
		
		int valor6;
		valor6 = 0;
		
		int valor7;
		valor7 = 0;
		
		int valor8;
		valor8 = 0;
		
		int valor9;
		valor9 = 0;
		
		int valor10;
		valor10 = 0;
		
		//Intrucción por teclado del valor de las variables referencia y el resto de valores del 1 al 10.
		System.out.println("Hola!Introduce un numero para darle un valor a referencia");
		referencia = teclado.nextInt();
		
		System.out.println("Introduce también un numero para el valor 1");
		valor1 = teclado.nextInt();
		
		System.out.println("Introduce un numero para el valor 2");
		valor2 = teclado.nextInt();
		
		System.out.println("Introduce un numero para el valor 3");
		valor3 = teclado.nextInt();
		
		System.out.println("Introduce un numero para el valor 4");
		valor4 = teclado.nextInt();
		
		System.out.println("Elige un numero para el valor 5");
		valor5 = teclado.nextInt();
		
		System.out.println("Asigna un numero para el valor 6");
		valor6 = teclado.nextInt();
		
		System.out.println("Introduce por teclado un numnero para el valor 7");
		valor7 = teclado.nextInt();
		
		System.out.println("Introduce un numero para el valor 8");
		valor8 =teclado.nextInt();
		
		System.out.println("Asigna un numero para el valor 9");
		valor9 = teclado.nextInt();
		
		System.out.println("Elige un numero para el valor 10");
		valor10= teclado.nextInt();
		
		//Ordenes de comparacion
		
		
		
		teclado.close();
	}

}
